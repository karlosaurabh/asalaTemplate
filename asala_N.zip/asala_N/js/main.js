// JavaScript Document 

/*=================== Open and Close script ======================*/ 
			  $(function() {
				$( "#accordion" ).accordion();
			  });
/*=================== Open and Close script end ======================*/


/*=================== FLIP BANNER PORTION script end ======================*/
   $('.card.hover').hover(function(){
		  
        $(this).addClass('flip');
      },function(){
        $(this).removeClass('flip');
      });

/*==============================*/
/*=====10. OWL CAR===*/
/*==============================*/  
  $(document).ready(function() {

      var owl = $("#owl-demo");

      owl.owlCarousel({

      items : 1, //10 items above 1000px browser width
      itemsDesktop : [1000,1], //5 items between 1000px and 901px
      itemsDesktopSmall : [900,1], // 3 items betweem 900px and 601px
      itemsTablet: [600,1], //2 items between 600 and 0;
      itemsMobile : true, // itemsMobile disabled - inherit from itemsTablet option
       autoPlay : false,
	   
      });
 $(".next").click(function(){
        owl.trigger('owl.next');
      })
      $(".prev").click(function(){
        owl.trigger('owl.prev');
      })
      // Custom Navigation Events
     /* $(".next").click(function(){
        owl.trigger('owl.next');
      })
      $(".prev").click(function(){
        owl.trigger('owl.prev');
      })
      $(".play").click(function(){
        owl.trigger('owl.play',1000);
      })
      $(".stop").click(function(){
        owl.trigger('owl.stop');
      })*/


    });
	  
/*==============================*/
/*=====10. background-scroll===*/
/*==============================*/
			
/*var $window = $(window);

    $('div[data-type="background"]').each(function(){
        // declare the variable to affect the defined data-type
        var $scroll = $(this);

        $(window).scroll(function() {
            // HTML5 proves useful for helping with creating JS functions!
            // also, negative value because we're scrolling upwards
            var yPos = -($window.scrollTop() / $scroll.data('speed'));

            // background position
            var coords = '50% '+ yPos + 'px';

            // move the background
            $scroll.css({ backgroundPosition: coords });
        }); // end window scroll
    });*/
 /*=============================*/
/*======10.SCROLLER UP======*/
/*===============================*/		
    $(document).ready(function() {

      $('.scroller_up a').smoothScroll({
	  	speed:2000,
		
	  });
    });
	
 /*=============================*/
/*======10.SCROLLER UP======*/
/*===============================*/			
/*==============================*/
/*=====10. MULTI ACCORDIAN===*/
/*==============================*/  
$(document).ready(function () {
			$('ul.accordion').accordion();
		});	 